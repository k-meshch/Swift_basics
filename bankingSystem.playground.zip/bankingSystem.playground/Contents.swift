import UIKit

class VirtualBankSystem {
    var accountType = ""
    var isOpened = true
    func welcomeCustomer() {
        print("Welcome to your virtual bank system.")
    }
    func onboardCustomerAccountOpening() {
        print("What kind of account would you like to open?")
        print("1. Debit account")
        print("2. Credit account")
    }
    func makeAccount(numberPadKey: Int) {
        print("The selected option is \(numberPadKey).")
        switch numberPadKey {
        case 1:
            accountType = "debit"
        case 2:
            accountType = "credit"
        default:
            print("Invalid input: \(numberPadKey)")
            return
        }
        print("You have opened a \(accountType) account.")
    }
    func moneyTransfer(transferType:String, transferAmount:Int, bankAccount: inout BankAcc) {
        switch transferType {
        case "withdraw":
            if accountType == "credit"{
                bankAccount.creditWithdraw(transferAmount)
        }
            else if accountType == "debit "{
                bankAccount.debitWithdraw(transferAmount)
        }
        case "deposit":
            if accountType == "credit"{
                bankAccount.creditDeposit(transferAmount)
            }
            else if accountType == "debit"{
                bankAccount.debitDeposit(transferAmount)
            }
        default: break
        }
    }
    func checkBalance(_ bankAccount:BankAcc){
        switch accountType {
        case "credit": print(bankAccount.creditBalance)
        case "debit": print(bankAccount.debitBalance)
        default: break
        }
    }
}


struct BankAcc {
    var debitBalance = 0
    var creditBalance = 0
    var creditLimit = 100
    var availableCredit: Int {
        creditBalance + creditLimit
    }
    
    var creditBalanceInfo: String {
        "Availiable credit $" + "\(availableCredit)."
    }
    
    var debitBalanceInfo: String {
        "Debit balance $" + "\(debitBalance)."
    }
    
    mutating func debitDeposit(_ amount:Int){
        debitBalance += amount
        print ("Deposited $\(amount). \(debitBalanceInfo)")
    }
    
    mutating func creditDeposit (_ amount:Int){
        creditBalance += amount
        print ("Deposited $\(amount). \(creditBalanceInfo)")
        if creditBalance == 0 {
            print("paid off credit balance.")
        }
        else {
            print("Overpaid credit balance.")
        }
    }
    
    mutating func debitWithdraw(_ amount: Int){
        if amount > debitBalance {
            print("Insufficient fund to withdraw $\(amount). \(debitBalanceInfo)")
        }
        else {
            debitBalance -= amount
            print("Debit withdraw: $\(amount). \(debitBalanceInfo)")
        }
    }
    
    mutating func creditWithdraw(_ amount: Int){
        if amount > availableCredit {
            print("Insufficient credit to withdraw $\(amount). \(creditBalanceInfo)")
        }
        else {
            creditBalance -= amount
            print("Credit withdraw: $\(amount). \(creditBalanceInfo)")
        }
    }
}

var myAcc = BankAcc()
print(myAcc.debitBalanceInfo)
myAcc.debitDeposit(100)
myAcc.debitWithdraw(20)
myAcc.debitWithdraw(81)
print(myAcc.creditBalanceInfo)
myAcc.creditWithdraw(101)
myAcc.creditWithdraw(100)
myAcc.creditDeposit(50)
myAcc.creditDeposit(50)
myAcc.creditDeposit(200)

print("\nWhat would you like to do?\n1. Check bank account\n2. Withdraw money\n3. Deposit money\n4. Close the system ")

var newBankAcc = BankAcc()
let virtualBankSystem = VirtualBankSystem()
repeat {
    let option = Int.random(in: 1...5)
    print("You chose \(option)")
    
    switch option {
    case 1: virtualBankSystem.checkBalance(newBankAcc)
    case 2: virtualBankSystem.moneyTransfer(transferType: "withdraw", transferAmount: 5, bankAccount: &newBankAcc)
    case 3: virtualBankSystem.moneyTransfer(transferType: "deposit", transferAmount: 6, bankAccount: &newBankAcc)
    case 4: virtualBankSystem.isOpened = false
    default: break
    }
} while virtualBankSystem.isOpened
