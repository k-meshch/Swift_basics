let day = "Monday"
let dailyTemp = 75
var temp = 70
temp =  80
let weekTemp = 73
temp = weekTemp
print("The temperature on \(day) is \(temp)")
